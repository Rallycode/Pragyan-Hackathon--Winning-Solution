TEAM PINNACLE
ECO CORP
Environmental Sustainability
Problem Statement: Real-Time Machine Learning for Pollution Reduction and
Maximize Environmental Impact
PROPOSED SOLUTION: It is a System where all the IT corporates take the initiative
to detect and reduce carbon emission of the industry and the workers. The
employees everyday carbon emission is calculated in Realtime and various tasks
and challenges are given to do carbon offset.
ECO2RP: A Realtime ML model to calculate and reduce the amount of carbon
released in Corporate Organisations.
OUR FOCUS:
1.Predictive Air Quality Management:
• The Model is trained to specially identify the amount of carbon released
during the usage of various hardware and software used in the corporate.
• It calculates the average carbon emitted by an employee of the corporate
2. Dynamic Resource Allocation for Environmental Initiatives:
• The model is trained to predict the average carbon emitted by each resource,
with that the resources are chosen wisely and allocated dynamically.
3. Enhanced Public Awareness and Engagement:
• Employees are made to take up challenges and complete tasks and they are
rewarded. E.g.: Plant Sapling, Carbon offset, Car-pooling, Use Public
Transport, Use Solar energy.
• The company’s which reduce their carbon emission for a period of time can
be certified with an ECO CORP badge
• The employees create awareness among their families.
• The corporates can complete among themselves to gain the badge ECO
CORP, it creates a Greener Future.